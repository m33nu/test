import * as institutionController from "./institution";
import * as submissionController from "./submision";
import * as subjectController from "./subject";

export {
    institutionController,
    submissionController,
    subjectController
};