import { Institution } from "../models/institution";

/**
 *  Creates an institution
 */
export const create = async (req, res, next) => {
    const { id, name, address, country, region } = req.body;
    var institution = Institution.create({ id, name, address, country, region })
    await institution.save()
    res.status(200).send(true);
};

/**
 *  Reads institution data given valid id
 */
export const read = async (req, res, next) => {
    const { id } = req.query;
    const institution = await Institution.findOne({ id })
    if (!institution) {
        res.status(404).json({
            code: "INSTITUTION_NOT_FOUND",
            message: "Institution not found!",
        });
        return;
    }
    res.json(institution);
};

/**
 * Updates institution data given valid id
 */
export const update = async (req, res) => {
    const { id, name, address, country, region } = req.body;
    var institution = await Institution.findOne({ id })
    if (!institution) {
        res.status(404).json({
            code: "INSTITUTION_NOT_FOUND",
            message: "Institution not found!",
        });
        return;
    }
    Institution.merge(institution, { name, address, country, region })
    await institution.save()
    res.status(200).send(true);
};

/**
 * List all the institutions
 */
export const list = async (req, res) => {
    const institutions = await Institution.find()
    res.json(institutions);
};

