import { Subject } from "../models/subject";

/**
 * List all the subjects and the institutions where these subjects are offered
 */
export const list = async (req, res) => {
    const subjects = await Subject.find({ relations: ["submission", "submission.institution"] })
    let result = {}
    for (let subject of subjects) {
        if (result[subject.name] === undefined) {
            result[subject.name] = []
        }
        result[subject.name].push(subject.submission.institution)
}
    res.json(result);
};